﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program_Matematyczny
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        private void button2_Click(object sender, EventArgs e)
        {
            label12.Text = "";
            label13.Text = "";
            label14.Text = "";
            label15.Text = "";
            label16.Text = "";
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
        }
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                double a, b, c, delta, x1, x2, p, q;
                a = double.Parse(textBox1.Text);
                b = double.Parse(textBox2.Text);
                c = double.Parse(textBox3.Text);
                delta = b * b - (4 * a * c);
                if (a==0)
                {
                    textBox1.Text = "";
                    textBox2.Text = "";
                    textBox3.Text = "";
                    MessageBox.Show("nie jest to funkcja kwadratowa");
                    
                }
                else
                if (delta < 0)
                {
                    label12.Text = "";
                    label13.Text = "";
                    label14.Text = "";
                    label15.Text = "";
                    label16.Text = "";
                    textBox1.Text = "";
                    textBox2.Text = "";
                    textBox3.Text = "";
                    MessageBox.Show("Brak miejsc zerowych delta mniejsza od 0");
                }
                else
                {
                    b = b * (-1);
                    delta = Math.Sqrt(delta);
                    x1 = (b + delta) / (2 * a);
                    x2 = (b - delta) / (2 * a);
                    delta = delta * delta;
                    p = b / (2 * a);
                    q = (-1) * delta / (4 * a);
                    b = b * (-1);
                    
                    if (x1 == x2)
                    {
                        label13.Text = Convert.ToString(Math.Round(x1, 3));
                        label14.Text = "";
                    }
                    else
                    {
                        label13.Text = Convert.ToString(Math.Round(x1, 3));
                        label14.Text = Convert.ToString(Math.Round(x2, 3));
                    }
                    label12.Text = Convert.ToString(Math.Round(delta, 3));
                    label15.Text = Convert.ToString(Math.Round(p, 3));
                    label16.Text = Convert.ToString(Math.Round(q, 3));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void fileToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void szukajToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                double a, b, c, delta, x1, x2, p, q;
                a = double.Parse(textBox1.Text);
                b = double.Parse(textBox2.Text);
                c = double.Parse(textBox3.Text);
                delta = b * b - (4 * a * c);
                if (a == 0)
                {
                    textBox1.Text = "";
                    textBox2.Text = "";
                    textBox3.Text = "";
                    MessageBox.Show("nie jest to funkcja kwadratowa");

                }
                else
                if (delta < 0)
                {
                    label12.Text = "";
                    label13.Text = "";
                    label14.Text = "";
                    label15.Text = "";
                    label16.Text = "";
                    textBox1.Text = "";
                    textBox2.Text = "";
                    textBox3.Text = "";
                    MessageBox.Show("Brak miejsc zerowych delta mniejsza od 0");
                }
                else
                {
                    b = b * (-1);
                    delta = Math.Sqrt(delta);
                    x1 = (b + delta) / (2 * a);
                    x2 = (b - delta) / (2 * a);
                    delta = delta * delta;
                    p = b / (2 * a);
                    q = (-1) * delta / (4 * a);
                    b = b * (-1);

                    if (x1 == x2)
                    {
                        label13.Text = Convert.ToString(Math.Round(x1, 3));
                        label14.Text = "";
                    }
                    else
                    {
                        label13.Text = Convert.ToString(Math.Round(x1, 3));
                        label14.Text = Convert.ToString(Math.Round(x2, 3));
                    }
                    label12.Text = Convert.ToString(Math.Round(delta, 3));
                    label15.Text = Convert.ToString(Math.Round(p, 3));
                    label16.Text = Convert.ToString(Math.Round(q, 3));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        
        }

        private void resetToolStripMenuItem_Click(object sender, EventArgs e)
        {
            label12.Text = "";
            label13.Text = "";
            label14.Text = "";
            label15.Text = "";
            label16.Text = "";
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
        }

        private void autorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Jakub Sachajko Autor Programu Miejsce Zerowe Funkcji");
        }
    }
}
